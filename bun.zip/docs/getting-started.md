---
title: Getting Started
description: An introduction to Equicord, helping new users begin with installation and usage.
---

# 🎯 Getting Started

## ❔ Where to Start?

Welcome to the Equicord documentation! This guide will help you get started with installing and using Equicord. Equicord is a Vencord fork that is actively maintained and updated by the Equicord team and contributors.

You have the ways to install Equicord for the 3 main Operating Systems: Linux, MacOS, and Windows.
