# Equidocs

[![Discord](https://img.shields.io/discord/1207691698386501634.svg?color=768AD4&label=Discord&logo=discord&logoColor=white)](https://discord.gg/equicord-1173279886065029291)  

## 📢 Join Our Community  

Stay updated with commits and changes by joining our [Discord server](https://discord.gg/equicord-1173279886065029291)!  

## 📖 About Equidocs  

**Equidocs** is an independent repository dedicated to documentation related to [Equicord](https://github.com/Equicord/Equicord).  

Our goal is to provide community-driven support and documentation for the Equicord project, making it easier for users to understand and contribute.  

---

Feel free to open issues or submit pull requests to improve Equidocs.
